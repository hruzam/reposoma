#!/usr/bin/env python3
"""Passive Codex skill-read assay for Linux.

Runs a command under strace while recording recursive inotify events.  It does
not modify the observed files or Codex configuration.
"""

from __future__ import annotations

import argparse
import ctypes
import ctypes.util
import datetime as dt
import json
import os
import pathlib
import platform
import selectors
import shutil
import signal
import struct
import subprocess
import sys
import threading
import time
from typing import IO, Any


EVENT = struct.Struct("iIII")
IN_ACCESS = 0x00000001
IN_MODIFY = 0x00000002
IN_ATTRIB = 0x00000004
IN_CLOSE_WRITE = 0x00000008
IN_CLOSE_NOWRITE = 0x00000010
IN_OPEN = 0x00000020
IN_MOVED_FROM = 0x00000040
IN_MOVED_TO = 0x00000080
IN_CREATE = 0x00000100
IN_DELETE = 0x00000200
IN_DELETE_SELF = 0x00000400
IN_MOVE_SELF = 0x00000800
IN_IGNORED = 0x00008000
WATCH_MASK = (
    IN_ACCESS | IN_MODIFY | IN_ATTRIB | IN_CLOSE_WRITE | IN_CLOSE_NOWRITE
    | IN_OPEN | IN_MOVED_FROM | IN_MOVED_TO | IN_CREATE | IN_DELETE
    | IN_DELETE_SELF | IN_MOVE_SELF
)
MASK_NAMES = [
    (IN_ACCESS, "ACCESS"), (IN_MODIFY, "MODIFY"), (IN_ATTRIB, "ATTRIB"),
    (IN_CLOSE_WRITE, "CLOSE_WRITE"), (IN_CLOSE_NOWRITE, "CLOSE_NOWRITE"),
    (IN_OPEN, "OPEN"), (IN_MOVED_FROM, "MOVED_FROM"),
    (IN_MOVED_TO, "MOVED_TO"), (IN_CREATE, "CREATE"),
    (IN_DELETE, "DELETE"), (IN_DELETE_SELF, "DELETE_SELF"),
    (IN_MOVE_SELF, "MOVE_SELF"), (IN_IGNORED, "IGNORED"),
]


def stamp() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds")


def emit(handle: IO[str], event: dict[str, Any]) -> None:
    event = {"ts": stamp(), **event}
    handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
    handle.flush()


class InotifyRecorder(threading.Thread):
    def __init__(self, root: pathlib.Path, output: pathlib.Path) -> None:
        super().__init__(daemon=True)
        self.root = root.resolve()
        self.output = output
        self.stop_flag = threading.Event()
        self.fd = -1
        self.watches: dict[int, pathlib.Path] = {}
        self.error: str | None = None

    def _add_tree(self, base: pathlib.Path) -> None:
        assert self.fd >= 0
        candidates = [base]
        candidates.extend(p for p in base.rglob("*") if p.is_dir())
        for directory in candidates:
            wd = self.libc.inotify_add_watch(
                self.fd, os.fsencode(directory), ctypes.c_uint32(WATCH_MASK)
            )
            if wd >= 0:
                self.watches[wd] = directory

    def run(self) -> None:
        libc_name = ctypes.util.find_library("c")
        if not libc_name:
            self.error = "libc not found"
            return
        self.libc = ctypes.CDLL(libc_name, use_errno=True)
        self.fd = self.libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
        if self.fd < 0:
            self.error = f"inotify_init1 failed: errno {ctypes.get_errno()}"
            return
        try:
            self._add_tree(self.root)
            selector = selectors.DefaultSelector()
            selector.register(self.fd, selectors.EVENT_READ)
            with self.output.open("a", encoding="utf-8") as handle:
                emit(handle, {"source": "inotify", "event": "WATCH_START", "root": str(self.root)})
                while not self.stop_flag.is_set():
                    for _key, _mask in selector.select(timeout=0.2):
                        try:
                            data = os.read(self.fd, 1024 * 128)
                        except BlockingIOError:
                            continue
                        offset = 0
                        while offset + EVENT.size <= len(data):
                            wd, mask, cookie, length = EVENT.unpack_from(data, offset)
                            offset += EVENT.size
                            raw_name = data[offset:offset + length]
                            offset += length
                            name = raw_name.rstrip(b"\0").decode(errors="surrogateescape")
                            parent = self.watches.get(wd, self.root)
                            path = parent / name if name else parent
                            names = [label for bit, label in MASK_NAMES if mask & bit]
                            emit(handle, {
                                "source": "inotify", "event": "|".join(names) or hex(mask),
                                "path": str(path), "cookie": cookie,
                            })
                            if mask & (IN_CREATE | IN_MOVED_TO) and path.is_dir():
                                self._add_tree(path)
                emit(handle, {"source": "inotify", "event": "WATCH_STOP", "root": str(self.root)})
        except Exception as exc:  # recorder failure must not kill Codex
            self.error = f"{type(exc).__name__}: {exc}"
        finally:
            if self.fd >= 0:
                os.close(self.fd)

    def stop(self) -> None:
        self.stop_flag.set()


def doctor() -> int:
    strace_path = shutil.which("strace")
    strace_usable = False
    strace_error = None
    if strace_path:
        probe = subprocess.run(
            [strace_path, "-qq", "-o", os.devnull, "-e", "trace=openat", "/usr/bin/true"],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True,
        )
        strace_usable = probe.returncode == 0
        if not strace_usable:
            strace_error = probe.stderr.strip() or f"exit {probe.returncode}"
    report = {
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "codex": shutil.which("codex"),
        "strace": strace_path,
        "strace_usable": strace_usable,
        "strace_error": strace_error,
        "rg": shutil.which("rg"),
        "script": str(pathlib.Path(__file__).resolve()),
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    missing = [name for name in ("codex", "strace") if not report[name]]
    if missing:
        print("BLOCKED: missing " + ", ".join(missing), file=sys.stderr)
        return 2
    if not strace_usable:
        print("BLOCKED: strace exists but ptrace is unavailable", file=sys.stderr)
        return 2
    print("SUPPORTED: required commands found")
    return 0


def run_trace(args: argparse.Namespace) -> int:
    root = pathlib.Path(args.root).resolve()
    if not root.is_dir():
        print(f"BLOCKED: observed root is not a directory: {root}", file=sys.stderr)
        return 2
    if not shutil.which("strace"):
        print("BLOCKED: strace not found", file=sys.stderr)
        return 2
    command = args.command or ["codex"]
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        command = ["codex"]

    run_id = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_dir = pathlib.Path(args.output).resolve() / run_id
    out_dir.mkdir(parents=True, exist_ok=False)
    event_path = out_dir / "fs-events.jsonl"
    raw_prefix = out_dir / "strace.raw"
    manifest = {
        "schema": 1, "started_at": stamp(), "root": str(root),
        "cwd": os.getcwd(), "command": command, "pid": os.getpid(),
        "outputs": {"events": str(event_path), "strace_prefix": str(raw_prefix)},
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    recorder = InotifyRecorder(root, event_path)
    recorder.start()
    trace_command = [
        "strace", "-ff", "-ttt", "-yy", "-s", "4096", "-o", str(raw_prefix),
        # Path-bearing calls are sufficient for this assay and avoid copying
        # file contents or terminal buffers into the raw trace.
        "-e", "trace=openat,openat2,close,newfstatat,statx",
        *command,
    ]
    print(f"ASSAY_RUN={out_dir}")
    print("Launching: " + " ".join(command))
    print("Exit Codex normally to finish the trace.")
    try:
        proc = subprocess.Popen(trace_command, cwd=root)
        return_code = proc.wait()
    except KeyboardInterrupt:
        if 'proc' in locals() and proc.poll() is None:
            proc.send_signal(signal.SIGINT)
            return_code = proc.wait()
        else:
            return_code = 130
    finally:
        recorder.stop()
        recorder.join(timeout=2)

    manifest.update({"finished_at": stamp(), "return_code": return_code, "inotify_error": recorder.error})
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    summarize(out_dir)
    if return_code != 0:
        print(f"BLOCKED: traced command exited with {return_code}", file=sys.stderr)
    return return_code


def summarize(run_dir: pathlib.Path) -> None:
    run_dir = run_dir.resolve()
    event_path = run_dir / "fs-events.jsonl"
    rows: list[dict[str, Any]] = []
    if event_path.exists():
        for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            path = item.get("path", "")
            if "SKILL.md" in path or "/.agents/skills/" in path or "/.codex/" in path:
                rows.append(item)

    syscall_lines: list[str] = []
    for raw in sorted(run_dir.glob("strace.raw*")):
        for line in raw.read_text(encoding="utf-8", errors="replace").splitlines():
            if "SKILL.md" in line or "/.agents/skills/" in line or "/.codex/" in line:
                syscall_lines.append(f"{raw.name}: {line}")

    summary = run_dir / "summary.txt"
    with summary.open("w", encoding="utf-8") as handle:
        handle.write(f"run: {run_dir}\n")
        handle.write(f"matching inotify events: {len(rows)}\n")
        handle.write(f"matching syscall lines: {len(syscall_lines)}\n\n")
        handle.write("INOTIFY\n")
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        handle.write("\nSTRACE\n")
        for line in syscall_lines:
            handle.write(line + "\n")
    print(f"SUMMARY={summary}")
    print(f"MATCHING_INOTIFY={len(rows)} MATCHING_SYSCALLS={len(syscall_lines)}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="subcommand", required=True)
    sub.add_parser("doctor", help="check required local commands")
    run = sub.add_parser("run", help="run Codex/a command under passive observation")
    run.add_argument("--root", required=True, help="directory to observe and use as cwd")
    run.add_argument("--output", required=True, help="parent directory for timestamped runs")
    run.add_argument("command", nargs=argparse.REMAINDER, help="command after --; defaults to codex")
    summary = sub.add_parser("summarize", help="rebuild a run summary")
    summary.add_argument("run_dir")
    args = parser.parse_args()
    if args.subcommand == "doctor":
        return doctor()
    if args.subcommand == "run":
        return run_trace(args)
    summarize(pathlib.Path(args.run_dir))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
