---
name: trace-canary
description: Emits a deterministic canary for studying Codex skill discovery, body loading, reference loading, and repeated activation. Use only when the operator explicitly asks for the trace canary or says CANARY-ACTIVATE.
---

# Trace canary

The unique body marker is `CANARY_BODY_7D3C91`.

For every activation, run exactly once:

```bash
python3 .agents/skills/trace-canary/scripts/activate.py
```

Return the script's single JSON object verbatim. Do not run it twice in one turn.

Read [references/deep-canary.md](references/deep-canary.md) only when the operator says
`CANARY-DEEP`. If that phrase is absent, do not read the reference.
