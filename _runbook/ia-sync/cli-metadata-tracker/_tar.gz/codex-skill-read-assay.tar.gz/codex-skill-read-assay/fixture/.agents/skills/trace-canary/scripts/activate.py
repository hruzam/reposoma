#!/usr/bin/env python3
"""Count semantic canary activations using a locked, append-only local log."""

import datetime as dt
import fcntl
import json
import os
import pathlib

root = pathlib.Path(os.getcwd()).resolve()
state_dir = root / ".assay-logs"
state_dir.mkdir(parents=True, exist_ok=True)
state_path = state_dir / "activation-state.json"
log_path = state_dir / "semantic-activations.jsonl"
lock_path = state_dir / "activation.lock"

with lock_path.open("a+") as lock:
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        state = {"count": 0}
    count = int(state.get("count", 0)) + 1
    state = {"count": count}
    temporary = state_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(state) + "\n", encoding="utf-8")
    os.replace(temporary, state_path)
    event = {
        "ts": dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds"),
        "event": "semantic_activation", "skill": "trace-canary", "count": count,
        "pid": os.getpid(),
    }
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, sort_keys=True) + "\n")
    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

result = {
    "marker": "CANARY_ACTIVATION_4AF207",
    "count": count,
    "operation": "SECOND_ACTIVATION_REACHED" if count == 2 else "ORDINARY_ACTIVATION",
}
print(json.dumps(result, sort_keys=True))
