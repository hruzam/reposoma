# Deep canary

The unique reference marker is `CANARY_REFERENCE_B842E6`.

When this file is deliberately requested, return that marker exactly once.
