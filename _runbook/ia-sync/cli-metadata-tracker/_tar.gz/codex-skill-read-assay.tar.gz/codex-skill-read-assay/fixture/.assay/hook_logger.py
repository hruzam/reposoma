#!/usr/bin/env python3
"""Append one Codex hook input to the assay log; never changes decisions."""

import datetime as dt
import json
import os
import pathlib
import sys

root = pathlib.Path(os.environ.get("CODEX_ASSAY_ROOT", os.getcwd())).resolve()
output = root / ".assay-logs" / "hooks.jsonl"
output.parent.mkdir(parents=True, exist_ok=True)
raw = sys.stdin.read()
try:
    payload = json.loads(raw)
except Exception as exc:
    payload = {"decode_error": str(exc), "raw": raw}
record = {
    "recorded_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds"),
    "logger_pid": os.getpid(),
    "payload": payload,
}
with output.open("a", encoding="utf-8") as handle:
    handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
