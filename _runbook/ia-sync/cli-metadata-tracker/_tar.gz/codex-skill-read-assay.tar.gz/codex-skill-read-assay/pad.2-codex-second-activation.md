# pad.2-codex-second-activation — correlate repeated skill use with reads and hooks

> Operator test surface. Sequential — one step, report back, next step.
> Driver: the driver. Run only after pad 1; reveal one step at a time.

Project path used in all commands:
`/home/hruzam/codex-skill-read-assay`

Precondition: pad 1 completed and the fixture is trusted as a local Codex project.

### STEP 0 — make a reversible clean state

```bash
mkdir -p /home/hruzam/codex-skill-read-assay/backups; if test -d /home/hruzam/codex-skill-read-assay/fixture/.assay-logs; then cp -a /home/hruzam/codex-skill-read-assay/fixture/.assay-logs "/home/hruzam/codex-skill-read-assay/backups/assay-logs.$(date +%Y%m%d-%H%M%S)"; fi; rm -f /home/hruzam/codex-skill-read-assay/fixture/.assay-logs/activation-state.json /home/hruzam/codex-skill-read-assay/fixture/.assay-logs/semantic-activations.jsonl /home/hruzam/codex-skill-read-assay/fixture/.assay-logs/hooks.jsonl; printf 'clean-state-ready\n'
```

Expected: `clean-state-ready`. Existing logs, if any, were copied before only the generated test-state files were removed.

- Exact output → proceed.
- Any permission/error output → STOP and flag the driver.

>MAJKEE report 0
```zsh

```

### STEP 1 — start the observed Codex sitting

```bash
python3 /home/hruzam/codex-skill-read-assay/trace_codex.py run --root /home/hruzam/codex-skill-read-assay/fixture --output /home/hruzam/codex-skill-read-assay/runs -- codex
```

If Codex reports untrusted hooks, open `/hooks`, inspect the project hook definition, and trust it. The hook only appends received event JSON under `fixture/.assay-logs/`.

Do not send the canary prompt yet.

- Codex reaches an idle prompt → proceed.
- Hook command differs from `.assay/hook_logger.py` or requests unrelated authority → STOP.

>MAJKEE report 1
```zsh

```

### STEP 2 — explicit first activation

Inside the same Codex session, send exactly:

```text
$trace-canary CANARY-ACTIVATE. Follow the skill and return its activation JSON verbatim.
```

Expected JSON contains:

```json
{"count": 1, "marker": "CANARY_ACTIVATION_4AF207", "operation": "ORDINARY_ACTIVATION"}
```

- Count `1` → SUPPORTED; proceed.
- Skill unavailable → inspect `/skills`; if absent, STOP and flag the driver.
- Count other than `1`, duplicate tool execution, or invented output → REFUTED; STOP.

>MAJKEE report 2
```zsh

```

### STEP 3 — explicit second activation in the same session

Inside the same Codex session, send the identical prompt again:

```text
$trace-canary CANARY-ACTIVATE. Follow the skill and return its activation JSON verbatim.
```

Expected JSON contains:

```json
{"count": 2, "marker": "CANARY_ACTIVATION_4AF207", "operation": "SECOND_ACTIVATION_REACHED"}
```

Then exit Codex normally.

- Exact second state → SUPPORTED: semantic repeat is proven.
- Count remains `1` or jumps beyond `2` → REFUTED: execution count is not one per activation.
- Correct response without corresponding log entry → REFUTED: model may have fabricated/cached output.

>MAJKEE report 3
```zsh

```

### STEP 4 — correlate the three observation surfaces

```bash
run_dir="$(find /home/hruzam/codex-skill-read-assay/runs -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2-)"; printf '%s\n' '=== SEMANTIC ==='; sed -n '1,80p' /home/hruzam/codex-skill-read-assay/fixture/.assay-logs/semantic-activations.jsonl; printf '%s\n' '=== FILE TRACE ==='; sed -n '1,240p' "$run_dir/summary.txt"; printf '%s\n' '=== HOOK EVENT NAMES ==='; python3 -c 'import json, pathlib; p=pathlib.Path("/home/hruzam/codex-skill-read-assay/fixture/.assay-logs/hooks.jsonl"); [print(json.loads(x).get("payload",{}).get("hook_event_name","?")) for x in p.read_text().splitlines()]'
```

Expected:

- exactly two semantic activation events with counts `1`, `2`;
- filesystem evidence showing how often the skill and script were opened/read;
- lifecycle events around prompts and tool calls.

Do not expect filesystem-read count to equal semantic count. Their difference is the experiment.

>MAJKEE report 4
```zsh

```

### STEP 5 — test reference-level progressive disclosure

Start one more traced session using the step 1 command. Send:

```text
$trace-canary CANARY-DEEP. Return the deep marker and do not activate the counter.
```

Expected: `CANARY_REFERENCE_B842E6`; after exit, the newest summary contains `deep-canary.md` access.

- Marker plus reference access → SUPPORTED: reference layer was loaded on demand.
- Marker without access → possible cache/model fabrication; mark INCONCLUSIVE.
- Access occurred before `CANARY-DEEP` in a clean session → REFUTED conditional-load prediction.

>MAJKEE report 5
```zsh

```

## Verdict map

| Step | Prediction | SUPPORTED when | REFUTED/BLOCKED when |
|---|---|---|---|
| 0 | State can be reset reversibly | Backup + clean counter | Cleanup fails |
| 1 | Hooks can be inspected/trusted | Idle Codex prompt | Unexpected hook authority |
| 2 | Body drives one real operation | Persistent count becomes 1 | Missing/duplicate/fabricated |
| 3 | Second semantic activation is distinct | Persistent count becomes 2 | Count mismatch |
| 4 | Surfaces can be correlated | Three logs agree on ordering | Missing evidence |
| 5 | Reference loads conditionally | Marker and access co-occur | Premature/missing access |

## parked

