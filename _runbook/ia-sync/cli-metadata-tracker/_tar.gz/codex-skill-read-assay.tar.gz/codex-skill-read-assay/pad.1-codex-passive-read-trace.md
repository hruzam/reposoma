# pad.1-codex-passive-read-trace — distinguish discovery from filesystem access

> Operator test surface. Sequential — one step, report back, next step.
> Driver: the driver. Reveal only the current step; paste the raw result into its report fence.

Project path used in all commands:
`/home/hruzam/codex-skill-read-assay`

Precondition: copy this complete kit to `/home/hruzam/codex-skill-read-assay`; no Codex configuration is changed by this PAD.

### STEP 0 — prove the local surface

```bash
python3 /home/hruzam/codex-skill-read-assay/trace_codex.py doctor
```

Expected: JSON paths for `codex` and `strace`, followed by `SUPPORTED`.

- `SUPPORTED` → proceed to step 1.
- `BLOCKED: missing strace` → install Arch package `strace`, then repeat step 0.
- Any other failure → STOP and flag the driver with the complete output.

>MAJKEE report 0
```zsh

```

### STEP 1 — establish an inert cold-start baseline

```bash
python3 /home/hruzam/codex-skill-read-assay/trace_codex.py run --root /home/hruzam/codex-skill-read-assay/fixture --output /home/hruzam/codex-skill-read-assay/runs -- codex
```

Inside Codex, send exactly:

```text
Reply with exactly BASELINE-OK. Do not use any skill or tool.
```

Then exit Codex normally. Expected after exit: `SUMMARY=.../summary.txt` and two match counts.

- Any count is evidence, not yet a verdict.
- Codex cannot start or the tracer crashes → STOP and flag the driver.

>MAJKEE report 1
```zsh

```

### STEP 2 — show the most recent baseline summary

```bash
run_dir="$(find /home/hruzam/codex-skill-read-assay/runs -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2-)"; sed -n '1,240p' "$run_dir/summary.txt"
```

Expected: accesses mentioning `.agents/skills/trace-canary/SKILL.md` may appear, but there should be no semantic activation log merely from the unrelated prompt.

- `SKILL.md` touched and no semantic activation → supports metadata/discovery access distinct from execution.
- No `SKILL.md` touch → supports registry/cache or a discovery path outside the watched fixture during this run.
- `.assay-logs/semantic-activations.jsonl` exists → REFUTED baseline; STOP and inspect why the body executed.

>MAJKEE report 2
```zsh

```

### STEP 3 — preserve the baseline verdict inputs

```bash
test ! -e /home/hruzam/codex-skill-read-assay/fixture/.assay-logs/semantic-activations.jsonl; printf 'semantic-log-exit=%s\n' "$?"; find /home/hruzam/codex-skill-read-assay/runs -mindepth 1 -maxdepth 2 -type f -printf '%p\n' | sort
```

Expected: `semantic-log-exit=0`; the file list includes manifest, filesystem events, raw strace files, and summary.

- Exit `0` → SUPPORTED: passive baseline completed.
- Exit `1` → REFUTED: semantic activation occurred; STOP and flag the driver.

>MAJKEE report 3
```zsh

```

## Verdict map

| Step | Prediction | SUPPORTED when | REFUTED/BLOCKED when |
|---|---|---|---|
| 0 | Required observer exists | Codex and strace found | Dependency absent |
| 1 | Cold start is observable | Run artifacts produced | Tracer/CLI fails |
| 2 | Access differs from activation | Reads may occur without activation | Body operation occurs |
| 3 | Baseline stayed inert | Semantic log absent | Semantic log exists |

## parked

