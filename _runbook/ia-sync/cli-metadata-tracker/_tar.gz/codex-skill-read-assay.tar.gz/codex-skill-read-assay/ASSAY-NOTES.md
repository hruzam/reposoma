# Codex skill-read assay — interpretation notes

This kit measures three different events and intentionally does not equate them:

1. filesystem access to `SKILL.md` and related paths;
2. Codex lifecycle hook events;
3. successful execution of the fixture skill's activation script.

The official Codex model is progressive: initial context contains skill metadata and path,
while the full `SKILL.md` is loaded after selection. Codex lifecycle hooks currently expose
session, prompt, tool, compaction, subagent, stop, and session-end surfaces; there is no
documented dedicated `SkillLoaded` hook. Therefore the assay treats skill loading as an
inference supported by filesystem evidence, not as a native event claim.

## Output ownership

- `runs/<timestamp>/manifest.json`: run conditions and command.
- `runs/<timestamp>/fs-events.jsonl`: recursive inotify stream.
- `runs/<timestamp>/strace.raw.*`: process-attributed syscall evidence.
- `runs/<timestamp>/summary.txt`: filtered convenience view; never the sole evidence.
- `fixture/.assay-logs/hooks.jsonl`: passive Codex hook inputs.
- `fixture/.assay-logs/semantic-activations.jsonl`: append-only successful operations.
- `fixture/.assay-logs/activation-state.json`: derived current count.

## Limits

- File reads can be repeated, partial, cached, performed by child processes, or caused by
  unrelated editors/indexers.
- `inotify` does not identify the reading process; use the paired `strace` record for that.
- `strace` changes timing and exposes local paths in its raw log. Review before sharing. The
  tracer limits capture to pathname-bearing file operations and does not trace `read`, `write`,
  network payloads, or terminal I/O.
- A correct model response is not proof of execution; the semantic JSONL record is.
- The fixture counter proves body-following behavior, not the exact internal moment when Codex
  injected `SKILL.md` into model context.

## Source baseline (checked 2026-08-21)

- OpenAI, “Build skills”: https://learn.chatgpt.com/docs/build-skills
- OpenAI, “Hooks”: https://learn.chatgpt.com/docs/hooks
- OpenAI, “Developer commands”: https://learn.chatgpt.com/docs/developer-commands

## AI HANDOFF
**Goal:** Observe Codex skill discovery, loading, and repeated semantic activation without modifying Codex internals.
**Current state:** Two sequential PADs and a Linux tracing fixture are ready for an operator run.
**Decisions made:** Separate filesystem, hook, and semantic signals; Python + standard Linux tracing; no FUSE/LD_PRELOAD mutation in the first assay.
**Files changed:** This assay kit only.
**Validation performed:** All Python sources compiled; hooks JSON parsed; fixture passed `quick_validate.py`; the semantic counter produced exact counts 1 then 2; the hook logger preserved a synthetic `PreToolUse` payload. Full `strace` execution was blocked by the hosted workspace's missing Codex binary and ptrace restriction, so the operator machine remains the integration boundary.
**Open questions / risks:** Exact Codex read/cache behavior is version-dependent; project hook trust is operator-controlled.
**Recommended next move:** Run pad 1 unchanged, then decide from its trace whether pad 2 needs adjustment.
**Agent:** Wave
